<template> 
    <omsPayments-detail :is-edit='true'>
</omsPayments-detail>
</template>
<script>
    import OmsPaymentsDetail from './components/detail'

    export default {
        name: 'updateOmsPayments',
        components: {OmsPaymentsDetail}
    }
</script>
<style>
</style>


