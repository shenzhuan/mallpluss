<template> 
    <omsCompanyAddress-detail :is-edit='true'>
</omsCompanyAddress-detail>
</template>
<script>
    import OmsCompanyAddressDetail from './components/detail'

    export default {
        name: 'updateOmsCompanyAddress',
        components: {OmsCompanyAddressDetail}
    }
</script>
<style>
</style>


