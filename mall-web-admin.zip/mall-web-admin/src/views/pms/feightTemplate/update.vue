<template> 
  <FeightTemplateDetail :is-edit='true'></FeightTemplateDetail>
</template>
<script>
  import FeightTemplateDetail from './components/FeightTemplateDetail'
  export default {
    name: 'updateFeightTemplateDetail',
    components: { FeightTemplateDetail }
  }
</script>
<style>
</style>


