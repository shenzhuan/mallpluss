<template> 
  <GiftsCategory-detail :is-edit='true'></GiftsCategory-detail>
</template>
<script>
  import GiftsCategoryDetail from './components/GiftsCategoryDetail'
  export default {
    name: 'updateGiftsCategory',
    components: { GiftsCategoryDetail }
  }
</script>
<style>
</style>


