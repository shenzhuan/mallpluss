<template> 
    <jifenDonateRule-detail :is-edit='false'>
</jifenDonateRule-detail>
</template>
<script>
    import JifenDonateRuleDetail from './components/detail'

    export default {
        name: 'addJifenDonateRule',
        components: {JifenDonateRuleDetail}
    }
</script>
<style>
</style>


