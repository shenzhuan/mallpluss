<template> 
    <jifenCoupon-detail :is-edit='true'>
</jifenCoupon-detail>
</template>
<script>
    import JifenCouponDetail from './components/detail'

    export default {
        name: 'updateJifenCoupon',
        components: {JifenCouponDetail}
    }
</script>
<style>
</style>


