<template> 
    <jifenCoupon-detail :is-edit='false'>
</jifenCoupon-detail>
</template>
<script>
    import JifenCouponDetail from './components/detail'

    export default {
        name: 'addJifenCoupon',
        components: {JifenCouponDetail}
    }
</script>
<style>
</style>


