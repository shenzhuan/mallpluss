<template> 
    <adminDayStatics-detail :is-edit='true'>
</adminDayStatics-detail>
</template>
<script>
    import AdminDayStaticsDetail from './components/detail'

    export default {
        name: 'updateAdminDayStatics',
        components: {AdminDayStaticsDetail}
    }
</script>
<style>
</style>


