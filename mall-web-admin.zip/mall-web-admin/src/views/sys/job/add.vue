<template> 
    <job-detail :is-edit='false'>
</job-detail>
</template>
<script>
    import JobDetail from './components/JobDetail'

    export default {
        name: 'addJob',
        components: {JobDetail}
    }
</script>
<style>
</style>


