<template> 
  <permissionCategory-detail :is-edit='true'></permissionCategory-detail>
</template>
<script>
  import PermissionCategoryDetail from './components/PermissionCategoryDetail'
  export default {
    name: 'updatePermissionCategory',
    components: { PermissionCategoryDetail }
  }
</script>
<style>
</style>


