<template> 
    <fenxiaoRecords-detail :is-edit='true'>
</fenxiaoRecords-detail>
</template>
<script>
    import FenxiaoRecordsDetail from './components/detail'

    export default {
        name: 'updateFenxiaoRecords',
        components: {FenxiaoRecordsDetail}
    }
</script>
<style>
</style>


