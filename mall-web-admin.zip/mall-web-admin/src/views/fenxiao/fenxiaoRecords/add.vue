<template> 
    <fenxiaoRecords-detail :is-edit='false'>
</fenxiaoRecords-detail>
</template>
<script>
    import FenxiaoRecordsDetail from './components/detail'

    export default {
        name: 'addFenxiaoRecords',
        components: {FenxiaoRecordsDetail}
    }
</script>
<style>
</style>


