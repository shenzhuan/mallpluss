<template> 
    <fenxiaoUserRelate-detail :is-edit='false'>
</fenxiaoUserRelate-detail>
</template>
<script>
    import FenxiaoUserRelateDetail from './components/detail'

    export default {
        name: 'addFenxiaoUserRelate',
        components: {FenxiaoUserRelateDetail}
    }
</script>
<style>
</style>


