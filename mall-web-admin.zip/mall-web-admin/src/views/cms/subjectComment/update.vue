<template> 
  <subjectComment-detail :is-edit='true'></subjectComment-detail>
</template>
<script>
  import SubjectCommentDetail from './components/SubjectCommentDetail'
  export default {
    name: 'updateSubjectComment',
    components: { SubjectCommentDetail }
  }
</script>
<style>
</style>


