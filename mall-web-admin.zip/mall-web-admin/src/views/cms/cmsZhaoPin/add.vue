<template> 
    <cmsZhaoPin-detail :is-edit='false'>
</cmsZhaoPin-detail>
</template>
<script>
    import CmsZhaoPinDetail from './components/detail'

    export default {
        name: 'addCmsZhaoPin',
        components: {CmsZhaoPinDetail}
    }
</script>
<style>
</style>


