<template> 
  <subjectCategory-detail :is-edit='false'></subjectCategory-detail>
</template>
<script>
  import SubjectCategoryDetail from './components/SubjectCategoryDetail'
  export default {
    name: 'addSubjectCategory',
    components: { SubjectCategoryDetail }
  }
</script>
<style>
</style>


