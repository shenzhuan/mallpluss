<template> 
  <memberReport-detail :is-edit='true'></memberReport-detail>
</template>
<script>
  import MemberReportDetail from './components/MemberReportDetail'
  export default {
    name: 'updateMemberReport',
    components: { MemberReportDetail }
  }
</script>
<style>
</style>


