<template> 
  <topicCategory-detail :is-edit='false'></topicCategory-detail>
</template>
<script>
  import TopicCategoryDetail from './components/TopicCategoryDetail'
  export default {
    name: 'addTopicCategory',
    components: { TopicCategoryDetail }
  }
</script>
<style>
</style>


