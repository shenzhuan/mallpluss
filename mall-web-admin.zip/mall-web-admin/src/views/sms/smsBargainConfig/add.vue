<template> 
    <smsBargainConfig-detail :is-edit='false'>
</smsBargainConfig-detail>
</template>
<script>
    import SmsBargainConfigDetail from './components/detail'

    export default {
        name: 'addSmsBargainConfig',
        components: {SmsBargainConfigDetail}
    }
</script>
<style>
</style>


