<template> 
  <userRedPacket-detail :is-edit='false'></userRedPacket-detail>
</template>
<script>
  import UserRedPacketDetail from './components/UserRedPacketDetail'
  export default {
    name: 'addUserRedPacket',
    components: { UserRedPacketDetail }
  }
</script>
<style>
</style>


