<template> 
  <baseMark-detail :isEdit="false"></baseMark-detail>
</template>
<script>
  import BaseMarkDetail from './components/BaseMarkDetail'
  export default {
    name: 'addBaseMark',
    components: { BaseMarkDetail }
  }
</script>
<style></style>


