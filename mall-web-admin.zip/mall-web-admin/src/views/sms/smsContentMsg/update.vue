<template> 
    <smsContentMsg-detail :is-edit='true'>
</smsContentMsg-detail>
</template>
<script>
    import SmsContentMsgDetail from './components/detail'

    export default {
        name: 'updateSmsContentMsg',
        components: {SmsContentMsgDetail}
    }
</script>
<style>
</style>


