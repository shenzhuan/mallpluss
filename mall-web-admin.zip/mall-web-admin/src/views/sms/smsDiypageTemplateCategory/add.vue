<template> 
    <smsDiypageTemplateCategory-detail :is-edit='false'>
</smsDiypageTemplateCategory-detail>
</template>
<script>
    import SmsDiypageTemplateCategoryDetail from './components/detail'

    export default {
        name: 'addSmsDiypageTemplateCategory',
        components: {SmsDiypageTemplateCategoryDetail}
    }
</script>
<style>
</style>


