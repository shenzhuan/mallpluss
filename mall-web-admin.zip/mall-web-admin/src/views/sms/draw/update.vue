<template> 
  <DrawDetail :is-edit='true'></DrawDetail>
</template>
<script>
  import DrawDetail from './components/DrawDetail'
  export default {
    name: 'updateDrawDetail',
    components: { DrawDetail }
  }
</script>
<style>
</style>


