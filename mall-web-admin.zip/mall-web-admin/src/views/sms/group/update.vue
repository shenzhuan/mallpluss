<template> 
  <group-detail :is-edit='true'></group-detail>
</template>
<script>
  import GroupDetail from './components/GroupDetail'
  export default {
    name: 'updateGroup',
    components: { GroupDetail }
  }
</script>
<style>
</style>


